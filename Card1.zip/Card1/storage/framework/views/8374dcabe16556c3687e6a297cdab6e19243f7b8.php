 
<?php $__env->startSection('content'); ?>
  
<?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="card text-center" style="background-color:#E83CB4; width:360px;border:groove; " >
  <div class="card-header " style="  width: 360px; height: 200px; ">
  <img src= "<?php echo e(Storage::url( $card->image)); ?>" alt="Card image cap" style=" width: 360px;
    height: 200px;">
  </div>
  <div class="card-body" style="padding-left:20px; text-align:center">
    <h5 class="card-title"><?php echo e($card->firstname); ?>  <?php echo e($card->lastname); ?></h5>
    <p class="card-text"><?php echo e($card->companyposition); ?></p>
     <h5 class="card-title"><?php echo e($card->phone); ?></h5>
  </div>
  <div class="card-footer text-muted">   
  </div>
</div>

 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>