<html>
    <head>
        <title>Card</title>
    </head>
    <body>
    

        <?php echo $__env->yieldContent('content'); ?>
    
        
    </body>
</html>