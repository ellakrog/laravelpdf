 
<?php $__env->startSection('content'); ?>
 
<?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <tr>
                        <td><?php echo e($card->firstname); ?></td>
                        <td><?php echo e($card->lastname); ?></td>
                        <td><?php echo e($card->copmpanyposition); ?></td>
                        <td><?php echo e($card->phone); ?></td>
                        <td><?php echo e($card->image); ?></td>
                    </tr>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>