@extends('layouts.master')
 
@section('content')
 
    <h2>Create business card</h2>
 
   

 
    <form method="post" action="/cards" enctype="multipart/form-data">
        {{ csrf_field() }}
        <div class="form-group row">
            <label for="firstname" class="col-sm-3 col-form-label">Firstname</label>
            <div class="col-sm-9">
                <input name="firstname" type="text" class="form-control" id="firstname" placeholder="Firstname">
            </div>
        </div>
        <div class="form-group row">
            <label for="lastname" class="col-sm-3 col-form-label">Lastname</label>
            <div class="col-sm-9">
                <input name="lastname" type="text" class="form-control" id="lastname" placeholder="Lastname">
            </div>
        </div>
        <div class="form-group row">
            <label for="companyposition" class="col-sm-3 col-form-label">companyposition</label>
            <div class="col-sm-9">
                <input name="companyposition" type="text" class="form-control" id="companyposition"
                       placeholder="company and Position">
            </div>
        </div>
        <div class="form-group row">
            <label for="phone" class="col-sm-3 col-form-label">Phone</label>
            <div class="col-sm-9">
                <input name="phone" type="text" class="form-control" id="phone"
                       placeholder="phone">
            </div>
        </div>
        <div class="form-group row">
            <label for="image" class="col-sm-3 col-form-label">card logo</label>
            <div class="col-sm-9">
                <input name="image" type="file" id="cardimageid" class="custom-file-input">
                <span style="margin-left: 15px; width: 480px;" class="custom-file-control"></span>
            </div>
        </div>
        <div class="form-group row">
            <div class="offset-sm-3 col-sm-9">
                <button type="submit" class="btn btn-primary">Submit </button>
            </div>
        </div>
    </form>
   
@endsection