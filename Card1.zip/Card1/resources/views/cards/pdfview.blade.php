@extends('layouts.master')
 
@section('content')
@foreach ($cards as $card)
<a href="{{ route('generate-pdf',['download'=>'pdf']) }}">Download PDF</a>
<div class="container">
	
	<div class="card-header " style="  width: 360px; height: 200px; ">
        <img src= "{{Storage::url( $card->image) }}" alt="Card image cap" style=" width: 360px;height: 200px;">
  </div>
  <div class="card-body" style="padding-left:20px; text-align:center">
    <h5 class="card-title">{{$card->firstname}}  {{$card->lastname}}</h5>
    <p class="card-text">{{$card->companyposition}}</p>
     <h5 class="card-title">{{$card->phone}}</h5>
  </div>
  <div class="card-footer text-muted">   
  </div>
</div>
@endforeach

@endsection