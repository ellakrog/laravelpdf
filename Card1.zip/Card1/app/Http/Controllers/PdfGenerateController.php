<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;

use App\Card;
use DB;
use PDF;
 
class PdfGenerateController extends Controller
{
    public function pdfview(Request $request)
    {
    $cards = DB::table("cards")->get();
    view()->share('cards',$cards);

    if($request->has('download')){
        // Set extra option
        PDF::setOptions(['dpi' => 150, 'defaultFont' => 'sans-serif']);
        // pass view file
        $pdf = PDF::loadView('cards.pdfview');
        // download pdf
        return $pdf->download('cards.pdfview.pdf');
    }
    return view('cards.pdfview');
}
}
