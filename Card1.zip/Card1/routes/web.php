<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', function () {
    return view('cards.create');
});

 
Route::get('cards/create', 'CardController@create');
 


Route::post('cards', 'CardController@store');

Route::get('cards', 'CardController@show');

Route::get('generate-pdf', 'PdfGenerateController@pdfview')->name('generate-pdf');
//Route::get('pdfview/{id}',array('as'=>'pdfview','uses'=>'PdfGenerateController@pdfview'));